<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('data_santri', function (Blueprint $table) {
            $table->bigIncrements('nis'); // Auto Increment
            $table->string('nama');
            $table->string('kelas');
            $table->string('kamar');
            $table->string('kontak');
            $table->timestamps();
        });

        // Buat trigger untuk auto increment dari 21214000
        DB::unprepared('
            ALTER TABLE data_santri AUTO_INCREMENT = 21214001;
        ');
    }

    public function down() {
        Schema::dropIfExists('data_santri');
    }
};
